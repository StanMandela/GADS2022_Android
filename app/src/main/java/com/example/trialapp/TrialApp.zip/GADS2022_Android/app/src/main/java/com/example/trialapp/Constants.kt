package com.example.trialapp

const val   NOTE_POSITION ="EXTRA_NOTE_POSITION"
const val   POSITION_IS_NOT_SET = 1